"""
Locust Telemetry Plugin
----------------------

This module defines the `LocustTelemetryPlugin`, which integrates
telemetry recording into Locust runs. It initializes master and
worker telemetry recorders to capture lifecycle events, request
statistics, and worker system metrics.

Responsibilities
----------------
- Register CLI arguments for telemetry configuration.
- Register master and worker telemetry recorders.
- Initialize telemetry manager and plugin manager.
"""
import logging
from typing import Any

from locust.env import Environment

from locust_telemetry import config
from locust_telemetry.core.plugin_manager import telemetry_plugin
from locust_telemetry.core.plugin_base import TelemetryPluginBase
from locust_telemetry.core_telemetry.master import MasterLocustTelemetryRecorder
from locust_telemetry.core_telemetry.worker import WorkerLocustTelemetryRecorder

logger = logging.getLogger(__name__)


@telemetry_plugin
class LocustTelemetryPlugin(TelemetryPluginBase):
    """
    Core telemetry plugin for Locust.

    Responsibilities
    ----------------
    - Register CLI arguments for telemetry configuration.
    - Load master-side telemetry recorders.
    - Load worker-side telemetry recorders.
    """

    PLUGIN_ID = config.TELEMETRY_STATS_RECORDER_PLUGIN_ID

    def add_cli_arguments(self, group: Any) -> None:
        """
        Plugins cli arguments

        Responsibilities
        ----------------
        - Register CLI arguments required for this telemetry plugin

         Parameters
        ----------
        group : Any (_ArgumentGroup)
            The telemetry plugin args group
        """
        group.add_argument(
            "--lt-stats-recorder-interval",
            type=int,
            help="Interval (in seconds) for telemetry statistics recorder updates.",
            env_var="LOCUST_TELEMETRY_STATS_RECORDER_INTERVAL",
            default=config.DEFAULT_STATS_RECORDER_INTERVAL,
        )
        group.add_argument(
            "--lt-system-usage-recorder-interval",
            type=int,
            help="Interval (in seconds) for system usage monitoring.",
            env_var="LOCUST_TELEMETRY_SYSTEM_USAGE_RECORDER_INTERVAL",
            default=config.DEFAULT_SYSTEM_USAGE_RECORDER_INTERVAL,
        )

    def load_master_telemetry_recorders(
        self, environment: Environment, **kwargs: Any
    ) -> None:
        """
        Register the telemetry recorder for the master node.

        Parameters
        ----------
        environment : Environment
            The Locust environment instance.
        **kwargs : Any
            Additional context passed by the orchestrator or event system.
        """
        MasterLocustTelemetryRecorder(env=environment)

    def load_worker_telemetry_recorders(
        self, environment: Environment, **kwargs: Any
    ) -> None:
        """
        Register the telemetry recorder for worker nodes.

        Parameters
        ----------
        environment : Environment
            The Locust environment instance.
        **kwargs : Any
            Additional context passed by the orchestrator or event system.
        """
        WorkerLocustTelemetryRecorder(env=environment)
