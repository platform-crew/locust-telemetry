"""
Plugin manager for Locust Telemetry.

Responsibilities
----------------
- Maintain a registry of telemetry plugins.
- Provide a singleton manager (one per process).
- Allow safe plugin registration (avoiding duplicates).
- Load and activate plugins according to the configuration provided by the user.
"""

from __future__ import annotations

import logging
from typing import Any, List

from locust.env import Environment

from locust_telemetry.core.plugin_base import TelemetryPluginBase

logger = logging.getLogger(__name__)


class TelemetryPluginManager:
    """
    Singleton class that manages telemetry plugin registration and loading.

    Responsibilities
    ----------------
    - Register plugins provided by extensions.
    - Maintain a central plugin registry per process.
    - Safely load plugins when requested by the orchestrator.
    """

    _instance: TelemetryPluginManager | None = None
    _initialized: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            logger.debug("[TelemetryPluginManager] Creating singleton instance")
        return cls._instance

    def __init__(self):
        """Initialize the plugin registry if not already initialized."""
        if self._initialized:
            return
        self._plugins: List[TelemetryPluginBase] = []
        self._initialized = True

    @property
    def plugins(self) -> List[TelemetryPluginBase]:
        """
        Return the list of registered plugins.

        Returns
        -------
        List[TelemetryPluginBase]
            The currently registered plugin instances.
        """
        return self._plugins

    def register_plugin(self, plugin: TelemetryPluginBase) -> None:
        """
        Register a telemetry plugin to be loaded later.

        Parameters
        ----------
        plugin : TelemetryPluginBase
            The plugin instance to register.
        """
        if plugin not in self._plugins:
            self._plugins.append(plugin)
            logger.debug(
                f"[TelemetryPluginManager] "
                f"Plugin registered: {plugin.__class__.__name__}"
            )
        else:
            logger.warning(
                f"[TelemetryPluginManager] Plugin already "
                f"registered: {plugin.__class__.__name__}"
            )

    def load_plugins(self, environment: Environment, **kwargs: Any) -> None:
        """
        Load all registered plugins.

        This method is typically invoked by ``TelemetryOrchestrator`` during
        Locust's init phase. Each plugin receives the current environment
        and optional event context.

        Parameters
        ----------
        environment : Environment
            The Locust environment instance.
        **kwargs : Any
            Additional context passed by the event system.
        """
        enabled_plugins = getattr(
            environment.parsed_options, "enable_telemetry_plugin", None
        )

        if not enabled_plugins:
            logger.info(
                "No telemetry plugin enabled. Use '--enable-telemetry-plugin' "
                "to activate one or more plugins."
            )
            return

        for plugin in self._plugins:
            if plugin.PLUGIN_ID not in enabled_plugins:
                continue

            try:
                plugin.load(environment=environment, **kwargs)
                logger.info(
                    f"[TelemetryPluginManager] Plugin loaded successfully: "
                    f"{plugin.__class__.__name__}"
                )
            except Exception:
                logger.exception(
                    f"[TelemetryPluginManager] Failed to load plugin: "
                    f"{plugin.__class__.__name__} "
                    f"in {environment.runner.__class__.__name__}. Enabled plugins: "
                    f"{enabled_plugins}"
                )


def telemetry_plugin(cls):
    manager = TelemetryPluginManager()
    manager.register_plugin(cls())
    return cls
