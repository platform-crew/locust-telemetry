"""
Locust Telemetry Entrypoint
--------------------------

Entry point for initializing telemetry in a Locust test run.
"""
import logging
from locust_telemetry.core.plugin_manager import TelemetryPluginManager
from locust_telemetry.core.orchestrator import TelemetryOrchestrator

logger = logging.getLogger(__name__)


def initialize(*args, **kwargs) -> None:
    """
    Register all the available plugins and start the orchestrator.

    For autodiscovery use only. Manual users should call `setup_telemetry()`.
    """
    orchestrator = TelemetryOrchestrator(
        plugin_manager=TelemetryPluginManager()
    )
    orchestrator.initialize()


def setup_telemetry() -> None:
    """
    High-level convenience initializer.

    Since Locust doesn’t have auto-discovery for plugins yet,
    this explicitly configures CLI args and initializes telemetry.
    """
    initialize()
