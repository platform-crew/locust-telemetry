"""
This module provides the `WorkerLocustTelemetryRecorder` class, which runs on
Locust worker nodes. It captures worker-specific telemetry such as CPU warnings
and logs them in a format suitable for observability tools.

Responsibilities
----------------
- Listen to worker-specific events: `cpu_warning`.
- Provide extension points for additional worker-level telemetry.
"""

import logging
import os
import socket
from typing import Any, ClassVar, Optional

from locust.env import Environment

from locust_telemetry.core_telemetry.common import LocustTelemetryCommonRecorder
from locust_telemetry.core_telemetry.constants import LocustTestEvent

logger = logging.getLogger(__name__)


class WorkerLocustTelemetryRecorder(LocustTelemetryCommonRecorder):
    """
    Telemetry recorder for Locust worker nodes.

    Responsibilities
    ----------------
    - Handle worker-specific telemetry, such as CPU warnings.
    - Provide extension points for additional worker-level telemetry.

    Attributes
    ----------
    name : ClassVar[str]
        Identifier for the recorder.
    """

    name: ClassVar[str] = "worker_locust_telemetry_recorder"
